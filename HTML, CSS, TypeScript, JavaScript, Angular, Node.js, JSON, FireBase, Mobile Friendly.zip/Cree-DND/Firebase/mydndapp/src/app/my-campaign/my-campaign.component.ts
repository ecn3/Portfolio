import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-campaign',
  templateUrl: './my-campaign.component.html',
  styleUrls: ['./my-campaign.component.css']
})
export class MyCampaignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
