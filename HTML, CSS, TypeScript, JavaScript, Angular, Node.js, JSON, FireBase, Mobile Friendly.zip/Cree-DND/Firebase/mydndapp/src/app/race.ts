export class Race {
    public name: string;
    public subraces: string;
    public publication: string;
    public title: string;
    public page: number;
    public img: string;
 }
 