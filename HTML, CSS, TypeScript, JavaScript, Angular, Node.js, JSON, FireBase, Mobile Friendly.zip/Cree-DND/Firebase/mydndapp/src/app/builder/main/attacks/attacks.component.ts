import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attacks',
  templateUrl: './attacks.component.html',
  styleUrls: ['./attacks.component.css']
})
export class AttacksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
