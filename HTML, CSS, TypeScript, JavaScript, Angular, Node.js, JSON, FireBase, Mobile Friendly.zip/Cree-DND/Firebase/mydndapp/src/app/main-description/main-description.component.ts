import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-description',
  templateUrl: './main-description.component.html',
  styleUrls: ['./main-description.component.css']
})
export class MainDescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
