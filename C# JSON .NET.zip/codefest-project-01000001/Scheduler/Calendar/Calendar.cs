﻿using System;
using System.Globalization;

public class TimeCalendar
{
    private DateTime date;
    private Calendar cal = CultureInfo.InvariantCulture.Calendar;
    private int year { get; set; }
    private int month { get; set; }
    private int day { get; set; }
    private int hour { get; set; }
    private int min { get; set; }

    //Default Constructor, sets to January 1, 2000
    public TimeCalendar()
    {
        date = new DateTime(2000, 1, 1, new GregorianCalendar());
    }

    //Parameterized Constructor
    public TimeCalendar(int newYear, int newMonth, int newDay, int newHour, int newMin)
    {
        year = newYear;
        month = newMonth;
        day = newDay;
        hour = newHour;
        min = newMin;

        date = new DateTime(newYear, newMonth, newDay, new GregorianCalendar());
        date = cal.AddHours(date, newHour);
        date = cal.AddMinutes(date, newMin);
    }

    public void SetYear(int newYear)
    {
        year = newYear - year;
        date = cal.AddYears(date, year);
    }

    public void SetMonth(int newMonth)
    {
        month = newMonth - month;
        date = cal.AddMonths(date, month);
    }

    public void SetDay(int newDay)
    {
        day = newDay - day;
        date = cal.AddDays(date, day);
    }

    public void SetHour(int newHour)
    {
        hour = newHour - hour;
        date = cal.AddHours(date, hour);
    }

    public void SetMin(int newMin)
    {
        min = newMin - min;
        date = cal.AddMinutes(date, min);
    }

    override
    public string ToString()
    {
        return date.ToString();
    }
}
