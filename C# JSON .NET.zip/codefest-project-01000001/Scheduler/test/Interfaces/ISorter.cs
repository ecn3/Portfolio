﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;

namespace test.Interfaces
{
    public interface ISorter
    {
        List<AssortedTask> SortTasks(List<SchedulerTask> tasks, List<BlockedTimes> blocks);
    }
}
