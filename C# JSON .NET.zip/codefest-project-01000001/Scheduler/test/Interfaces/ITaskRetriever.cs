﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;

namespace test.Interfaces
{
    public interface ITaskRetriever
    {
        List<SchedulerTask> GetTasksByDay(DateTime day);
        List<SchedulerTask> GetAllTasks();
    }
}
