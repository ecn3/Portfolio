﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;

namespace test.Interfaces
{
    public interface ITaskStorer
    {
        void SaveTasks(List<SchedulerTask> tasks);
        void SaveTask(SchedulerTask tasks);
    }
}
