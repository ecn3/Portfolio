﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;

namespace test.Interfaces
{
    public interface IBlockStorer
    {
        void SaveBlocks(List<BlockedTimes> blocks);
        void SaveBlock(BlockedTimes blocks);
    }
}
