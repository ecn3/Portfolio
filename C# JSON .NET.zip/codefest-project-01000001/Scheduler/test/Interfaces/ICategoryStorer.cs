﻿namespace test.Interfaces
{
    public interface ICategoryStorer
    {
        void StoreCategoryDuration(string category, int time);
    }
}
