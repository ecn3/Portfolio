﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.Data;
using test.Factory;

namespace test
{
    public partial class Main : Form
    {
        private SchedulerFactory factory;
        private bool justOpened = true;

        public Main(SchedulerFactory factory)
        {
            this.factory = factory;
            InitializeComponent();
            UpdateTaskList(DateTime.Now);
            //UpdateBlockList(DateTime.Now);
        }
        

        private void button1_Click(object sender, EventArgs e) //for add task button
        {
            TaskEntryForm ftask = new TaskEntryForm(factory.taskStorer, factory.categoryRetriever, factory.categoryRegistrar); // create new form object
            ftask.ShowDialog(); // opens form 2
            UpdateTaskView(null, null);
        }

        private void button2_Click(object sender, EventArgs e) //for add restriction button
        {
            Prefrences fPrefrences = new Prefrences(factory.blockStorer, factory); // create new form object
            fPrefrences.ShowDialog(); // opens form 2
            UpdateTaskView(null, null);
        }

        private void taskView_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTaskView(null, null);
        }

        private void UpdateTaskView(object sender, DateRangeEventArgs e)
        {
            switch (taskView.SelectedIndex)
            {
                case 0:
                    UpdateListView();
                    break;
                case 1:
                    UpdateWeekView();
                    break;
                case 2:
                    break;
                default:
                    break;
            }
        }
        
        private void UpdateListView()
        {
            dataGridView1.Rows.Clear();
            UpdateTaskList(monthCalendar1.SelectionRange.Start);
            //UpdateBlockList(monthCalendar1.SelectionRange.Start);
        }

        private void UpdateTaskList(DateTime day)
        {
            DateTime selected = day;
            List<SchedulerTask> tasks = factory.taskRetriever.GetTasksByDay(selected);
            List<AssortedTask> assortedTasks = factory.taskSorter.SortTasks(factory.taskRetriever.GetAllTasks(), factory.blockRetriever.GetAllBlocks());
            if (assortedTasks == null)
                return;

            int currentRow = 0;
            foreach(AssortedTask task in assortedTasks)
            {
                if(task.day.Day == monthCalendar1.SelectionRange.Start.Day)
                {
                    foreach(SchedulerTask testTask in tasks)
                    {
                        if(testTask.id == task.id)
                        {
                            //dataGridView1.Rows.Add(testTask.TaskName, testTask.Duration, task.);
                            int mod = task.startTime % 2;
                            int startHour = task.startTime / 2;
                            int minutes = mod * 30;
                            string extraZero = minutes == 0 ? "0" : "";
                            string time = startHour + ":" + minutes + extraZero;

                            int durationHours = testTask.Duration / 60;
                            int durationMinutes = (testTask.Duration / 30) % 2 == 0 ? 0 : 30;
                            int endTimeMinutes = minutes + durationMinutes;
                            durationHours = endTimeMinutes == 60 ? durationHours + 1 : durationHours;
                            endTimeMinutes = endTimeMinutes == 60 ? endTimeMinutes = 0 : endTimeMinutes;
                            string extraZero2 = endTimeMinutes == 0 ? "0" : "";
                            string endTime = (startHour + durationHours) + ":" + endTimeMinutes + extraZero2;

                            dataGridView1.Rows.Add(testTask.TaskName, time, endTime);
                            if (testTask.completed)
                            {
                                dataGridView1.Rows[currentRow].Cells[0].Style.BackColor = Color.Gray;
                                dataGridView1.Rows[currentRow].Cells[1].Style.BackColor = Color.Gray;
                                dataGridView1.Rows[currentRow].Cells[2].Style.BackColor = Color.Gray;
                            }
                            currentRow++;
                        }
                    }
                }
            }
            UpdateBlockList(day, currentRow);
        }

        private void UpdateBlockList(DateTime day, int currentRow)
        {
            DateTime selected = day;
            List<BlockedTimes> blocks = factory.blockRetriever.GetBlocksByDay(selected);

            foreach (BlockedTimes block in blocks)
            {
                dataGridView1.Rows.Add(block.TaskName, block.StartTime, block.EndTime);
                dataGridView1.Rows[currentRow].Cells[0].Style.BackColor = Color.Red;
                dataGridView1.Rows[currentRow].Cells[1].Style.BackColor = Color.Red;
                dataGridView1.Rows[currentRow].Cells[2].Style.BackColor = Color.Red;
                currentRow++;
            }
        }

        private void UpdateWeekView()
        {
            Color[] colors = { Color.Moccasin, Color.Aqua, Color.Chartreuse, Color.DarkKhaki, Color.Green, Color.DeepPink, Color.Goldenrod, Color.MidnightBlue,
                Color.PaleGreen, Color.MistyRose };
            dataGridView2.Rows.Clear();
            dataGridView2.Columns.Clear();
            dataGridView2.ColumnCount = 7;

            DateTime startDay = monthCalendar1.SelectionRange.Start;

            for (int i = 0; i < dataGridView2.ColumnCount; i++)
            {
                DateTime localTime = startDay.AddDays(i);
                dataGridView2.Columns[i].Name = localTime.DayOfWeek.ToString().Substring(0, 3);
                dataGridView2.Columns[i].DataPropertyName = localTime.ToString();
            }

            dataGridView2.AutoResizeColumns();

            dataGridView2.RowTemplate.Height = 6;
            for (int i = 0; i < 48; i++)
            {
                dataGridView2.Rows.Add();
            }


            for (int i = 0; i < dataGridView2.ColumnCount; i++)
            {
                DateTime localTime = startDay.AddDays(i);
                List<BlockedTimes> blocks = factory.blockRetriever.GetBlocksByDay(localTime);
                foreach(BlockedTimes block in blocks)
                {
                    int rowStartIndex = block.StartTimeHour * 2 + block.StartTimeHour / 30;
                    int rowEndIndex = block.EndTimeHour * 2 + block.EndTimeHour / 30;
                    if (rowEndIndex > 47)
                        rowEndIndex = 47;

                    for(int j = rowStartIndex; j < rowEndIndex; j++)
                    {
                        dataGridView2.Rows[j].Cells[i].Style.BackColor = Color.Red;
                    }
                }
            }

            List<AssortedTask> assortedTasks = factory.taskSorter.SortTasks(factory.taskRetriever.GetAllTasks(), factory.blockRetriever.GetAllBlocks());
            if (assortedTasks == null)
                return;
            int colorIndex = 0;
            for (int i = 0; i < dataGridView2.ColumnCount; i++)
            {
                DateTime localTime = startDay.AddDays(i);
                foreach(AssortedTask task in assortedTasks)
                {
                    if(task.day.Day == localTime.Day)
                    {
                        int rowStartIndex = task.startTime;
                        int rowEndIndex = task.startTime + task.duration / 30;
                        if (rowEndIndex > 47)
                            rowEndIndex = 47;
                        
                        for (int j = rowStartIndex; j < rowEndIndex; j++)
                        {
                            dataGridView2.Rows[j].Cells[i].Style.BackColor = colors[colorIndex];
                        }
                        if (colorIndex == colors.Length - 1)
                            colorIndex = 0;
                        else
                            colorIndex++;
                    }
                }
            }
        }

        private void preferencesOnClick(object sender, EventArgs e)
        {
            MessageBox.Show("You have no control here.");
        }

        private void fileCloseOnClick(object sender, EventArgs e)
        {
            MessageBox.Show("There is no escape from your priorities.");
        }

        private void onCellChange(object sender, EventArgs e)
        {
            if (justOpened)
                justOpened = false;
            else
            {
                List<SchedulerTask> tasks = factory.taskRetriever.GetAllTasks();
                SchedulerTask task = null;

                foreach (SchedulerTask hmmTask in tasks)
                {
                    try
                    {
                        if (dataGridView1.SelectedCells[0].Value.ToString() == hmmTask.TaskName)
                            task = hmmTask;
                    }
                    catch(Exception ex)
                    {

                    }
                }
                if (task == null || task.completed)
                    return;
                
                try
                {
                    TaskReview review = new TaskReview(task, factory.categoryStorer, factory.taskStorer);
                    review.ShowDialog();
                }
                catch(Exception ex)
                {

                }
            }
        }
    }
}