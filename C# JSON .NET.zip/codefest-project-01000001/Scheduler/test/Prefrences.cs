﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;
using System.Windows.Forms;
using test.Interfaces;
using test.Factory;

namespace test
{
    public partial class Prefrences : Form
    {
        private IBlockStorer storer;
        private SchedulerFactory factory;

        public Prefrences(IBlockStorer storer, SchedulerFactory factory)
        {
            this.factory = factory;
            this.storer = storer;
            InitializeComponent();
            populateDataGrid();
        }
        public void populateDataGrid()
        {
            DateTime selected = monthCalendar1.SelectionRange.Start;
            List<BlockedTimes> blocks = factory.blockRetriever.GetBlocksByDay(selected);

            foreach (BlockedTimes block in blocks)
            {
                dataGridView1.Rows.Add(block.StartTime, block.EndTime);
            }
        }
        public string blockedTimes;

        public Prefrences()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
           // blockedTimes += (textBox1.Text + System.Environment.NewLine);
            //richTextBox1.Text = blockedTimes;

            BlockedTimes block = new BlockedTimes();
            block.StartTimeHour = int.Parse(numericUpDown1.Text); //takes in hour
            block.StartTimeMinute = int.Parse(numericUpDown2.Text); //takes in hour
            block.EndTimeHour = int.Parse(numericUpDown4.Text); //takes in hour
            block.EndTimeMinute = int.Parse(numericUpDown3.Text); //takes in hour
            block.TaskName = textBox1.Text;

            block.StartTime = (block.StartTimeHour + ":" + block.StartTimeMinute);
            block.EndTime = (block.EndTimeHour + ":" + block.EndTimeMinute);

            if (block.StartTimeMinute == 0)
            {
                block.StartTime += "0";
            }
            if (block.EndTimeMinute == 0)
            {
                block.EndTime += "0";
            }
            //temp until we get the algorithm going
            //richTextBox1.Text = (block.StartTimeHour + ":" + block.StartTimeMinute);

           

            block.ScheduledDay = monthCalendar1.SelectionRange.Start;


            storer.SaveBlock(block);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DateTime selected = monthCalendar1.SelectionRange.End;
            List<BlockedTimes> blocks = factory.blockRetriever.GetBlocksByDay(selected);
            foreach (BlockedTimes block in blocks)
            {
                if (block.StartTimeHour == int.Parse(numericUpDown1.Text)) {
                    blocks.Remove(block);
                    storer.SaveBlocks(blocks);
                    break;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            DateTime selected = monthCalendar1.SelectionRange.End;
            List<BlockedTimes> blocks = factory.blockRetriever.GetBlocksByDay(selected);

            foreach (BlockedTimes block in blocks)
            {
                dataGridView1.Rows.Add(block.StartTime, block.EndTime);
            }

        }

        private void Prefrences_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            DateTime myDate = monthCalendar1.SelectionRange.Start;

            System.DayOfWeek i = myDate.DayOfWeek;

            DateTime endOfMonth = new DateTime();
            endOfMonth = endOfMonth.AddMonths(1).AddDays(-1);

            for (int j = 0; myDate.Day < endOfMonth.Day; j++) // does for one month
            {

                if ((i == System.DayOfWeek.Sunday) || (i == System.DayOfWeek.Saturday))
                {
                    BlockedTimes block = new BlockedTimes();
                    block.ScheduledDay = myDate;
                    block.StartTimeHour = 0;
                    block.EndTimeHour = 23;
                    block.StartTimeMinute = 0;
                    block.EndTimeMinute = 30;
                    block.StartTime = (block.StartTimeHour + ":" + block.StartTimeMinute);
                    block.EndTime = (block.EndTimeHour + ":" + block.EndTimeMinute);
                    block.TaskName = "Weekend";
                    storer.SaveBlock(block);

                    if (i == System.DayOfWeek.Sunday)
                    {
                        myDate = myDate.AddDays(6); //iterates day to next day
                    }
                    else{
                        myDate = myDate.AddDays(1);
                    }
                }
                i = myDate.DayOfWeek;

            }

            }


           
       
        }
    }
