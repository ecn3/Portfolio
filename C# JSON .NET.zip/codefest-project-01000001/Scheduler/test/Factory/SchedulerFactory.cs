﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Manager;
using test.Interfaces;

namespace test.Factory
{
    public class SchedulerFactory
    {
        public ICategoryRegistrar categoryRegistrar { get; private set; }
        public ICategoryRetriever categoryRetriever { get; private set; }
        public IBlockRetriever blockRetriever { get; private set; }
        public IBlockStorer blockStorer { get; private set; }
        public ITaskRetriever taskRetriever { get; private set; }
        public ITaskStorer taskStorer { get; private set; }
        public ISorter taskSorter { get; private set; }
        public ICategoryStorer categoryStorer { get; private set; }

        public SchedulerFactory()
        {
            categoryRegistrar = new JSONCategoryRegistrar();
            categoryRetriever = new JSONCategoryRetriever();
            blockRetriever = new JSONBlockRetriever();
            blockStorer = new JSONBlockStorer();
            taskRetriever = new JSONRetriever();
            taskStorer = new JSONStorer();
            taskSorter = new TaskSort();
            categoryStorer = new JSONCategoryStorer();
        }
    }
}
