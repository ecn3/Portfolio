﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.Data;
using test.Interfaces;

namespace test
{
    public partial class TaskEntryForm : Form
    {
        private ITaskStorer storer;
        private ICategoryRetriever categoryRetriever;
        private ICategoryRegistrar categoryRegistrar;

        public TaskEntryForm(ITaskStorer storer, ICategoryRetriever categoryRetriever, ICategoryRegistrar categoryRegistrar)
        {
            this.storer = storer;
            this.categoryRetriever = categoryRetriever;
            this.categoryRegistrar = categoryRegistrar;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SchedulerTask task = new SchedulerTask();
            try
            {
                task.Category = comboBox1.Text;
                task.Difficulty = (int)numericUpDown1.Value;
                task.Priority = (int)numericUpDown2.Value;
                task.Duration = int.Parse(comboBox4.Text);
                task.DueDate = dateTimePicker1.Value;
                task.TaskName = textBox1.Text;
                task.id = -1;
            }
            catch(FormatException error){}

            //temp until we get the algorithm going
            task.ScheduledDay = dateTimePicker1.Value;

            storer.SaveTask(task);

            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateApproxTime(object sender, EventArgs e)
        {
            comboBox4.Text = CategoryApproxCalculator.DetermineApproxTime(comboBox1.Text, categoryRetriever, categoryRegistrar);
        }
        private void TaskEntryForm_Load(object sender, EventArgs e)
        {
        }
    }
}
