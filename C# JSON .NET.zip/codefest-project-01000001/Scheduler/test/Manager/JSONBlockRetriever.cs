﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class JSONBlockRetriever : IBlockRetriever
    {
        public List<BlockedTimes> GetBlocksByDay(DateTime day)
        {
            List<BlockedTimes> blocks = new List<BlockedTimes>();
            FileStream file = new FileStream("./blocks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(blocks.GetType());
            blocks = ser.ReadObject(file) as List<BlockedTimes>;
            file.Close();

            List<BlockedTimes> filteredTasks = new List<BlockedTimes>();
            foreach (BlockedTimes block in blocks)
            {
                if (block.ScheduledDay.Date == day.Date)
                    filteredTasks.Add(block);
            }

            return filteredTasks;
        }

        public List<BlockedTimes> GetAllBlocks()
        {
            List<BlockedTimes> blocks = new List<BlockedTimes>();
            FileStream file = new FileStream("./blocks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(blocks.GetType());
            blocks = ser.ReadObject(file) as List<BlockedTimes>;
            file.Close();

            return blocks;
        }
    }
}
