﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class JSONStorer : ITaskStorer
    {
        public void SaveTask(SchedulerTask task)
        {
            bool preExistingTask = false;
            List<SchedulerTask> tasks = new List<SchedulerTask>();
            FileStream file = new FileStream("./tasks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(tasks.GetType());
            tasks = ser.ReadObject(file) as List<SchedulerTask>;
            file.Close();

            foreach(SchedulerTask oldTask in tasks)
            {
                if (oldTask.id == task.id)
                {
                    oldTask.completed = true;
                    preExistingTask = true;
                }
            }

            if(!preExistingTask)
            {
                int taskID = 0;
                foreach (SchedulerTask oldTask in tasks)
                {
                    taskID++;
                }
                task.id = taskID;
                tasks.Add(task);
            }

            SaveTasks(tasks);
        }

        public void SaveTasks(List<SchedulerTask> tasks)
        {
            FileStream file = new FileStream("./tasks.json", FileMode.Create);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(List<SchedulerTask>));
            ser.WriteObject(file, tasks);
            file.Close();
        }
    }
}
