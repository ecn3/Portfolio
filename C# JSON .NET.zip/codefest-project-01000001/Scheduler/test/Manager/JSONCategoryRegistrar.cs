﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Json;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class JSONCategoryRegistrar : ICategoryRegistrar
    {
        public void RegisterCategory(string category)
        {
            Dictionary<string, List<int>> categories = new Dictionary<string, List<int>>();
            FileStream file = new FileStream("./categories.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(categories.GetType());
            try
            {
                categories = ser.ReadObject(file) as Dictionary<string, List<int>>;
            }
            catch(Exception e)
            {

            }
            file.Close();

            List<int> emptySet = new List<int>();

            categories.Add(category, emptySet);

            SaveCategories(categories);
        }

        private void SaveCategories(Dictionary<string, List<int>> categories)
        {
            FileStream file = new FileStream("./categories.json", FileMode.Create);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Dictionary<string, List<int>>));
            ser.WriteObject(file, categories);
            file.Close();
        }
    }
}
