﻿using System;
using System.Runtime.Serialization.Json;
using System.Collections.Generic;
using System.IO;
using test.Interfaces;

namespace test.Manager
{
    public class JSONCategoryRetriever : ICategoryRetriever
    {
        public List<int> GetPreviousDurations(string category)
        {
            Dictionary<string, List<int>> storedCategoryInfo = new Dictionary<string, List<int>>();
            FileStream file = new FileStream("./categories.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(storedCategoryInfo.GetType());

            try
            {
                storedCategoryInfo = ser.ReadObject(file) as Dictionary<string, List<int>>;
            }
            catch (Exception e)
            {
                file.Close();
                return null;
            }

            file.Close();

            List<int> previousDurations = new List<int>();

            try
            {
                previousDurations = storedCategoryInfo[category];
            }
            catch (KeyNotFoundException e)
            {
                return null;
            }

            return previousDurations;
        }
    }
}
