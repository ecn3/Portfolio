﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class TaskSort : ISorter
    {
        public List<AssortedTask> SortTasks(List<SchedulerTask> tasks, List<BlockedTimes> blocks)
        {
            if (tasks.Count == 0)
                return null;
            tasks.Sort(delegate(SchedulerTask a, SchedulerTask b)
            {
                if (a.DueDate > b.DueDate)
                    return 1;
                else
                    return -1;
            });

            List<List<SchedulerTask>> buckets = new List<List<SchedulerTask>>();
            int currentBucket = 0;
            DateTime currentDueDate = tasks[0].DueDate;
            buckets.Add(new List<SchedulerTask>());
            buckets[currentBucket].Add(tasks[0]);

            for (int i = 1; i < tasks.Count; i++)
            {
                if(tasks[i].DueDate.Day == currentDueDate.Day)
                {
                    buckets[currentBucket].Add(tasks[i]);
                }
                else
                {
                    buckets.Add(new List<SchedulerTask>());
                    currentBucket++;
                    currentDueDate = tasks[i].DueDate;
                    buckets[currentBucket].Add(tasks[i]);
                }
            }

            foreach (List<SchedulerTask> bucket in buckets)
            {
                bucket.Sort(delegate (SchedulerTask a, SchedulerTask b)
                {
                    if (a.Priority < b.Priority)
                        return 1;
                    else
                        return -1;
                });
            }

            List<SchedulerTask> sortedTasks = new List<SchedulerTask>();

            foreach(List<SchedulerTask> bucket in buckets)
            {
                foreach(SchedulerTask task in bucket)
                {
                    sortedTasks.Add(task);
                }
            }

            List<AssortedTask> assortedTasks = new List<AssortedTask>();
            foreach(SchedulerTask task in sortedTasks)
            {
                AssortedTask skeletonTask = new AssortedTask();
                skeletonTask.day = task.DueDate;
                skeletonTask.duration = task.Duration;
                skeletonTask.id = task.id;
                skeletonTask.startTime = 0;
                skeletonTask.overlap = false;
                assortedTasks.Add(skeletonTask);
            }
            int previousTaskStartTime = 0;
            int previousTaskEndTime = 0;
            DateTime previousDate = assortedTasks[0].day;
            bool first = true;
            foreach(AssortedTask task in assortedTasks)
            {
                List<BlockedTimes> relevantBlockedTimes = new List<BlockedTimes>();
                foreach(BlockedTimes block in blocks)
                {
                    if(block.ScheduledDay.Day == task.day.Day)
                    {
                        relevantBlockedTimes.Add(block);
                    }
                }

                for(int i = 0; i < relevantBlockedTimes.Count; i++)
                {
                    int endBlockIndex = relevantBlockedTimes[i].EndTimeHour * 2 + relevantBlockedTimes[i].EndTimeMinute / 30;
                    if (endBlockIndex > task.startTime)
                    {
                        task.startTime = endBlockIndex;
                    }

                    int startBlockIndex = relevantBlockedTimes[i].StartTimeHour * 2 + relevantBlockedTimes[i].StartTimeMinute / 30;
                    if(task.startTime + task.duration / 30 > startBlockIndex)
                    {
                        task.startTime = endBlockIndex;
                    }
                }

                if(first)
                {
                    first = false;
                }
                else if(task.day.Day != previousDate.Day)
                {
                    previousTaskStartTime = 0;
                    previousTaskEndTime = 0;
                    previousDate = task.day;
                }
                else if ((task.startTime >= previousTaskStartTime && task.startTime <= previousTaskEndTime) ||
                    (task.startTime + task.duration / 30 >= previousTaskStartTime && task.startTime + task.duration / 30 <= previousTaskEndTime))
                {
                    task.startTime = previousTaskEndTime;
                }

                previousTaskStartTime = task.startTime;
                previousTaskEndTime = task.startTime + task.duration / 30;
            }

            return assortedTasks;
        }
    }
}
