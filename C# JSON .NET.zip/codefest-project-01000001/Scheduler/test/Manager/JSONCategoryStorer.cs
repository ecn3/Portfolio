﻿using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Collections.Generic;
using test.Interfaces;
using test.Data;

namespace test.Manager
{
    public class JSONCategoryStorer : ICategoryStorer
    {
        public void StoreCategoryDuration(string category, int time)
        {
            Dictionary<string, List<int>> categories = new Dictionary<string, List<int>>();
            FileStream file = new FileStream("./categories.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(categories.GetType());
            categories = ser.ReadObject(file) as Dictionary<string, List<int>>;
            file.Close();

            categories[category].Add(time);

            file = new FileStream("./categories.json", FileMode.Create);
            ser = new DataContractJsonSerializer(typeof(Dictionary<string, List<int>>));
            ser.WriteObject(file, categories);
            file.Close();
        }
    }
}
