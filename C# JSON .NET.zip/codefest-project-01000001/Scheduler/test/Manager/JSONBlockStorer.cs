﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class JSONBlockStorer : IBlockStorer
    {
        public void SaveBlock(BlockedTimes block)
        {
            List<BlockedTimes> blocks = new List<BlockedTimes>();
            FileStream file = new FileStream("./blocks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(blocks.GetType());
            blocks = ser.ReadObject(file) as List<BlockedTimes>;
            file.Close();

            blocks.Add(block);

            SaveBlocks(blocks);
        }

        public void SaveBlocks(List<BlockedTimes> blocks)
        {
            FileStream file = new FileStream("./blocks.json", FileMode.Create);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(List<BlockedTimes>));
            ser.WriteObject(file, blocks);
            file.Close();
        }
    }
}
