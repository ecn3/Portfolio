﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using test.Data;
using test.Interfaces;

namespace test.Manager
{
    public class JSONRetriever : ITaskRetriever
    {
        public List<SchedulerTask> GetTasksByDay(DateTime day)
        {
            List<SchedulerTask> tasks = new List<SchedulerTask>();
            FileStream file = new FileStream("./tasks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(tasks.GetType());
            tasks = ser.ReadObject(file) as List<SchedulerTask>;
            file.Close();

            List<SchedulerTask> filteredTasks = new List<SchedulerTask>();
            foreach (SchedulerTask task in tasks)
            {
                if (task.ScheduledDay.Date == day.Date)
                    filteredTasks.Add(task);
            }

            return filteredTasks;
        }

        public List<SchedulerTask> GetAllTasks()
        {
            List<SchedulerTask> tasks = new List<SchedulerTask>();
            FileStream file = new FileStream("./tasks.json", FileMode.OpenOrCreate);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(tasks.GetType());
            tasks = ser.ReadObject(file) as List<SchedulerTask>;
            file.Close();

            return tasks;
        }
    }
}
