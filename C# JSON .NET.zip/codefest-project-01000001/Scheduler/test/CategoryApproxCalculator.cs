﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Interfaces;

namespace test
{
    public class CategoryApproxCalculator
    {        
        public static string DetermineApproxTime(string category, ICategoryRetriever retriever, ICategoryRegistrar registrar)
        {
            List<int> previousDurations = retriever.GetPreviousDurations(category);

            if(previousDurations == null)
            {
                registrar.RegisterCategory(category);
                previousDurations = new List<int>();
                previousDurations.Add(30);
                return ((int)previousDurations.Average()).ToString();
            }

            if(previousDurations.Count == 0)
            {
                return "30";
            }
            
            return ((int)previousDurations.Average()).ToString();
        }
    }
}
