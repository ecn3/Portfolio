﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.Data;
using test.Interfaces;

namespace test
{
    public partial class TaskReview : Form
    {
        private SchedulerTask task;
        private ICategoryStorer categoryStorer;
        private ITaskStorer taskStorer;

        public TaskReview(SchedulerTask task, ICategoryStorer categoryStorer, ITaskStorer taskStorer)
        {
            this.categoryStorer = categoryStorer;
            this.taskStorer = taskStorer;
            this.task = task;
            InitializeComponent();
            textBox1.Text = task.TaskName;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            categoryStorer.StoreCategoryDuration(task.Category, (int)(numericUpDown1.Value));
            taskStorer.SaveTask(task);
            Hide();
        }
    }
}
