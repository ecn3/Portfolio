﻿using System;

namespace test.Data
{
    public class BlockedTimes
    {
        public DateTime ScheduledDay;
        public int StartTimeHour;
        public int StartTimeMinute;
        public String StartTime;
        public int EndTimeHour;
        public int EndTimeMinute;
        public String EndTime;
        public string TaskName;
        public int position; // stored so array can place in correct part of day[hour]
        public int id;
    }
}
