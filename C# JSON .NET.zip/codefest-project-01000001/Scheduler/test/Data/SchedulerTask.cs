﻿using System;

namespace test.Data
{
    public class SchedulerTask
    {
        public string Category;
        public string TaskName;
        public DateTime ScheduledDay;
        public int Duration;
        public DateTime DueDate;
        public int Difficulty;
        public int Priority;
        public int position; // stored so array can place in correct part of day[hour]
        public int id;
        public bool completed = false;
    }
}
