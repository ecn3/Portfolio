﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test.Data
{
    public class AssortedTask
    {
        public int id;
        public DateTime day;
        public int startTime;
        public int duration;
        public bool overlap;
    }
}
