# The beginning of Schedular, from codefest-project-01000001.

## Trello board link: https://trello.com/b/LpaI3wwc/01000001

Build Using C# and .NET
# GIT COMMANDS
  #### git pull 
  //Pulls current build in github(this will delete any code that you have not pushed.
  #### git checkout -b NewBranchName
    //creates new branch
  #### git add *
    //gathers up new code
  #### git commit -m "your DESCRIPTIVE message about what you did"
    //The message that will be linked to your add
  #### git push origin NewBranchName
    //sends new code to the branch NewBranchName
