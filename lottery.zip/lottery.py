# Christian Nelson
# Lottery

# Import Statements
import pandas as pd
from pandas import Series, DataFrame
import numpy as np

# Formats
fm_string_int = "{} {}"
fm_pick = "{} {}, {}, {}, {}, {}, Ball: {}"

# Load lotteries into a DATAFRAMES
power_ball_df = pd.read_csv('PowerBall.csv')
mega_millions_df = pd.read_csv('MegaMillions.csv')

# Get Columns
pb_cols = list(power_ball_df)
pb_cols.remove('Draw Date')



#----------------------- Functions -----------------------#

# Function for getting counts per value
def get_value_counts(df, column):
    return df[column].value_counts()

# Function for getting unique values
def get_unique_values(df, column):
    return df[column].unique()

# Combine counts function
def add_counts(list,counts):
    for i in list.index:
        counts[i] = list[i]+counts[i] 

#----------------------- Power Ball -----------------------#

# Get value counts of power ball
pb_1 = get_value_counts(power_ball_df, pb_cols[0])
pb_2 = get_value_counts(power_ball_df, pb_cols[1])
pb_3 = get_value_counts(power_ball_df, pb_cols[2])
pb_4 = get_value_counts(power_ball_df, pb_cols[3])
pb_5 = get_value_counts(power_ball_df, pb_cols[4])
pb_6 = get_value_counts(power_ball_df, pb_cols[5])

# Get unique values
pb1_unique = get_unique_values(power_ball_df, pb_cols[0])
pb2_unique = get_unique_values(power_ball_df, pb_cols[1])
pb3_unique = get_unique_values(power_ball_df, pb_cols[2])
pb4_unique = get_unique_values(power_ball_df, pb_cols[3])
pb5_unique = get_unique_values(power_ball_df, pb_cols[4])
pb6_unique = get_unique_values(power_ball_df, pb_cols[5])

# Total Counts of pb
pb_counts = [0] * 70

# Add all counts
add_counts(pb_1,pb_counts)
add_counts(pb_2,pb_counts)
add_counts(pb_3,pb_counts)
add_counts(pb_4,pb_counts)
add_counts(pb_5,pb_counts)

# Create series of pb counts
pb_count_ser = pd.Series(pb_counts) 
pb_count_ser = pb_count_ser.sort_values(ascending=False)

# Get picks
top_5_pbr = pb_count_ser[:5].index
pb_ball =  pd.Series(pb_6[:1]).index
top5_pbt = [pb_1.index[0],pb_2.index[0],pb_3.index[0],pb_4.index[0],pb_5.index[0]]

#----------------------- Mega Millions -----------------------#

# Get value counts of power ball
mm_1 = get_value_counts(mega_millions_df, pb_cols[0])
mm_2 = get_value_counts(mega_millions_df, pb_cols[1])
mm_3 = get_value_counts(mega_millions_df, pb_cols[2])
mm_4 = get_value_counts(mega_millions_df, pb_cols[3])
mm_5 = get_value_counts(mega_millions_df, pb_cols[4])
mm_6 = get_value_counts(mega_millions_df, pb_cols[5])

# Get unique values
mm1_unique = get_unique_values(mega_millions_df, pb_cols[0])
mm2_unique = get_unique_values(mega_millions_df, pb_cols[1])
mm3_unique = get_unique_values(mega_millions_df, pb_cols[2])
mm4_unique = get_unique_values(mega_millions_df, pb_cols[3])
mm5_unique = get_unique_values(mega_millions_df, pb_cols[4])
mm6_unique = get_unique_values(mega_millions_df, pb_cols[5])

# Total Counts of pb
mm_counts = [0] * 76

# Add all counts
add_counts(mm_1,mm_counts)
add_counts(mm_2,mm_counts)
add_counts(mm_3,mm_counts)
add_counts(mm_4,mm_counts)
add_counts(mm_5,mm_counts)

# Create series of pb counts
mm_count_ser = pd.Series(mm_counts) 
mm_count_ser = mm_count_ser.sort_values(ascending=False)

# Get picks
top_5_mmr = mm_count_ser[:5].index
mm_ball =  pd.Series(mm_6[:1]).index
top5_mmt = [mm_1.index[0],mm_2.index[0],mm_3.index[0],mm_4.index[0],mm_5.index[0]]


#----------------------- Print -----------------------#

# recurrence of pb pick
print(fm_pick.format("Power Ball top numbers by recurrence:",
top_5_pbr[0], 
top_5_pbr[1],
top_5_pbr[2],
top_5_pbr[3],
top_5_pbr[4],
pb_ball[0]))


# pb pick by ticket
print(fm_pick.format("Power Ball top numbers by ticket spot:",
top5_pbt[0], 
top5_pbt[1],
top5_pbt[2],
top5_pbt[3],
top5_pbt[4],
pb_ball[0]))

# Space
print("")

# recurrence of mm pick
print(fm_pick.format("Mega Millions top numbers by recurrence:",
top_5_mmr[0], 
top_5_mmr[1],
top_5_mmr[2],
top_5_mmr[3],
top_5_mmr[4],
mm_ball[0]))


# pb pick by ticket
print(fm_pick.format("Mega Millions top numbers by ticket spot:",
top5_mmt[0], 
top5_mmt[1],
top5_mmt[2],
top5_mmt[3],
top5_mmt[4],
mm_ball[0]))



            

